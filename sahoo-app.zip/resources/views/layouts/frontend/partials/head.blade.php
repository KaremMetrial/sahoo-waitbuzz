<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sahoo</title>
<!-- normalize css file -->
<link rel="stylesheet" href="{{ asset('assets/frontend/css/normalize.css') }}">
<!-- bootstrap css file -->
<link rel="stylesheet" href="{{ asset('assets/frontend/css/bootstrap.min.css') }}">
<!-- font awesome css file -->
<link rel="stylesheet" href="{{ asset('assets/frontend/css/all.min.css') }}">
<!-- swiper -->
<link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/>
<!-- main css file -->
<link rel="stylesheet" href="{{ asset('assets/frontend/css/main.css') }}">
<!-- google font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800;900&display=swap" rel="stylesheet">
@stack('frontend-css')
