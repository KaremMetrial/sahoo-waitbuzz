<div class="quality my-5">
    <div class="container">
        <h3 class="header">{{ __('quality_you_feel') }}</h3>
        <p class="section-p">{{ __('quality_description') }}</p>
        <div class="swiper centered-swiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="{{ asset('assets/frontend/images/quality.png') }}" alt="">
                </div>
                <div class="swiper-slide">
                    <img src="{{ asset('assets/frontend/images/quality.png') }}" alt="">
                </div>
                <div class="swiper-slide">
                    <img src="{{ asset('assets/frontend/images/quality.png') }}" alt="">
                </div>
                <div class="swiper-slide">
                    <img src="{{ asset('assets/frontend/images/quality.png') }}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
