@extends('layouts.frontend.master')
@section('content')
    <!-- contact us -->
@include('frontend.home.partials.contact-us')
@endsection
